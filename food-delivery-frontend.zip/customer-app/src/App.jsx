import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import BottomNav from './components/BottomNav'
import Home from './pages/Home'
import Search from './pages/Search'
import RestaurantDetail from './pages/RestaurantDetail'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import OrderTracking from './pages/OrderTracking'
import Orders from './pages/Orders'
import Profile from './pages/Profile'
import Login from './pages/Login'
import OtpVerify from './pages/OtpVerify'

function RequireAuth({ children }) {
  const { isAuthed } = useApp()
  const location = useLocation()
  if (!isAuthed) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

function Shell() {
  const location = useLocation()
  const hideNav = ['/login', '/otp'].includes(location.pathname) ||
    location.pathname.startsWith('/restaurant/') ||
    location.pathname === '/cart' ||
    location.pathname === '/checkout' ||
    location.pathname.includes('/track')

  return (
    <>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/otp" element={<OtpVerify />} />
        <Route path="/" element={<RequireAuth><Home /></RequireAuth>} />
        <Route path="/search" element={<RequireAuth><Search /></RequireAuth>} />
        <Route path="/restaurant/:id" element={<RequireAuth><RestaurantDetail /></RequireAuth>} />
        <Route path="/cart" element={<RequireAuth><Cart /></RequireAuth>} />
        <Route path="/checkout" element={<RequireAuth><Checkout /></RequireAuth>} />
        <Route path="/order/:orderId/track" element={<RequireAuth><OrderTracking /></RequireAuth>} />
        <Route path="/orders" element={<RequireAuth><Orders /></RequireAuth>} />
        <Route path="/profile" element={<RequireAuth><Profile /></RequireAuth>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {!hideNav && <BottomNav />}
    </>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}
