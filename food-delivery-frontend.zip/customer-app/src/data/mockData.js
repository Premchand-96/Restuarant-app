// Mock data layer — stands in for the Backend API until one exists.

export const categories = [
  { id: 'c1', name: 'Biryani', emoji: '🍛' },
  { id: 'c2', name: 'Pizza', emoji: '🍕' },
  { id: 'c3', name: 'South Indian', emoji: '🥞' },
  { id: 'c4', name: 'Desserts', emoji: '🍮' },
  { id: 'c5', name: 'Burgers', emoji: '🍔' },
  { id: 'c6', name: 'Chinese', emoji: '🥡' },
]

export const restaurants = [
  {
    id: 'r1',
    name: 'Paradise Biryani House',
    cuisines: ['Biryani', 'Mughlai', 'North Indian'],
    rating: 4.4,
    ratingCount: 2380,
    priceForTwo: 400,
    deliveryTime: 32,
    distanceKm: 2.1,
    offer: '50% OFF up to ₹100',
    veg: false,
    photo: 'biryani-restaurant',
    address: 'Tirupati Main Road, Near Bus Stand',
  },
  {
    id: 'r2',
    name: 'Green Leaf Tiffins',
    cuisines: ['South Indian', 'Vegetarian'],
    rating: 4.6,
    ratingCount: 1520,
    priceForTwo: 250,
    deliveryTime: 25,
    distanceKm: 1.4,
    offer: 'Free delivery',
    veg: true,
    photo: 'south-indian',
    address: 'AIR Bypass Road',
  },
  {
    id: 'r3',
    name: 'Napoli Wood-Fired Pizza',
    cuisines: ['Pizza', 'Italian'],
    rating: 4.3,
    ratingCount: 980,
    priceForTwo: 600,
    deliveryTime: 38,
    distanceKm: 3.6,
    offer: '20% OFF above ₹500',
    veg: false,
    photo: 'pizza',
    address: 'Renigunta Road',
  },
  {
    id: 'r4',
    name: 'Golden Dragon',
    cuisines: ['Chinese', 'Asian'],
    rating: 4.1,
    ratingCount: 640,
    priceForTwo: 450,
    deliveryTime: 30,
    distanceKm: 2.8,
    offer: null,
    veg: false,
    photo: 'chinese',
    address: 'Tirchanur Road',
  },
  {
    id: 'r5',
    name: 'Sugar & Ghee Sweets',
    cuisines: ['Desserts', 'Sweets'],
    rating: 4.7,
    ratingCount: 3100,
    priceForTwo: 150,
    deliveryTime: 20,
    distanceKm: 0.9,
    offer: 'Buy 1 Get 1',
    veg: true,
    photo: 'desserts',
    address: 'Gandhi Road',
  },
  {
    id: 'r6',
    name: 'Smokehouse Burgers',
    cuisines: ['Burgers', 'American'],
    rating: 4.2,
    ratingCount: 810,
    priceForTwo: 350,
    deliveryTime: 27,
    distanceKm: 2.3,
    offer: '₹75 OFF above ₹250',
    veg: false,
    photo: 'burgers',
    address: 'Leela Mahal Circle',
  },
]

export const menus = {
  r1: [
    {
      category: 'Biryani',
      items: [
        { id: 'i1', name: 'Hyderabadi Chicken Biryani', desc: 'Slow-cooked basmati, tender chicken, saffron', price: 260, veg: false, bestseller: true },
        { id: 'i2', name: 'Mutton Biryani', desc: 'Rich, spiced, dum-cooked mutton biryani', price: 320, veg: false, bestseller: false },
        { id: 'i3', name: 'Veg Dum Biryani', desc: 'Mixed vegetables and basmati, dum-sealed', price: 210, veg: true, bestseller: false },
      ],
    },
    {
      category: 'Starters',
      items: [
        { id: 'i4', name: 'Chicken 65', desc: 'Deep-fried spiced chicken bites', price: 190, veg: false, bestseller: true },
        { id: 'i5', name: 'Paneer Tikka', desc: 'Char-grilled marinated paneer', price: 180, veg: true, bestseller: false },
      ],
    },
  ],
  r2: [
    {
      category: 'Tiffins',
      items: [
        { id: 'i6', name: 'Masala Dosa', desc: 'Crisp dosa, spiced potato filling', price: 90, veg: true, bestseller: true },
        { id: 'i7', name: 'Idli Sambar (4pc)', desc: 'Steamed rice cakes, sambar, chutney', price: 70, veg: true, bestseller: false },
        { id: 'i8', name: 'Pesarattu', desc: 'Green gram dosa with ginger chutney', price: 85, veg: true, bestseller: false },
      ],
    },
  ],
  r3: [
    {
      category: 'Pizza',
      items: [
        { id: 'i9', name: 'Margherita', desc: 'San Marzano tomato, fior di latte, basil', price: 320, veg: true, bestseller: true },
        { id: 'i10', name: 'Pepperoni Classico', desc: 'Double pepperoni, mozzarella', price: 420, veg: false, bestseller: true },
      ],
    },
  ],
  r4: [
    {
      category: 'Mains',
      items: [
        { id: 'i11', name: 'Kung Pao Chicken', desc: 'Wok-tossed chicken, peanuts, chili', price: 280, veg: false, bestseller: true },
        { id: 'i12', name: 'Veg Hakka Noodles', desc: 'Stir-fried noodles, garden vegetables', price: 190, veg: true, bestseller: false },
      ],
    },
  ],
  r5: [
    {
      category: 'Sweets',
      items: [
        { id: 'i13', name: 'Kaju Katli (250g)', desc: 'Cashew fudge, silver leaf', price: 220, veg: true, bestseller: true },
        { id: 'i14', name: 'Gulab Jamun (6pc)', desc: 'Milk-solid dumplings in rose syrup', price: 120, veg: true, bestseller: false },
      ],
    },
  ],
  r6: [
    {
      category: 'Burgers',
      items: [
        { id: 'i15', name: 'Smoked BBQ Chicken Burger', desc: 'Smoked chicken patty, BBQ glaze, slaw', price: 220, veg: false, bestseller: true },
        { id: 'i16', name: 'Classic Veg Burger', desc: 'Crumb-fried veg patty, cheese, sauces', price: 160, veg: true, bestseller: false },
      ],
    },
  ],
}

export const addons = {
  i1: [{ id: 'a1', name: 'Extra Raita', price: 20 }, { id: 'a2', name: 'Boiled Egg', price: 15 }],
  i9: [{ id: 'a3', name: 'Extra Cheese', price: 60 }, { id: 'a4', name: 'Stuffed Crust', price: 90 }],
}

export const mockUser = {
  id: 'u1',
  name: 'Aarav Reddy',
  phone: '+91 98765 43210',
  email: 'aarav.reddy@example.com',
  addresses: [
    { id: 'ad1', label: 'Home', line: '12-3-45, Balaji Nagar, Tirupati', isDefault: true },
    { id: 'ad2', label: 'Work', line: '2nd Floor, IT Park, Renigunta Road', isDefault: false },
  ],
  paymentMethods: [
    { id: 'p1', type: 'UPI', label: 'aarav@okhdfcbank' },
    { id: 'p2', type: 'Card', label: 'Visa •••• 4821' },
  ],
}

export const initialOrders = [
  {
    id: 'ORD1001',
    restaurantId: 'r1',
    restaurantName: 'Paradise Biryani House',
    items: [{ name: 'Hyderabadi Chicken Biryani', qty: 2, price: 260 }],
    total: 585,
    status: 'delivered',
    placedAt: '2026-09-05T13:20:00',
    rated: true,
  },
  {
    id: 'ORD1002',
    restaurantId: 'r5',
    restaurantName: 'Sugar & Ghee Sweets',
    items: [{ name: 'Gulab Jamun (6pc)', qty: 1, price: 120 }],
    total: 145,
    status: 'delivered',
    placedAt: '2026-09-01T18:05:00',
    rated: false,
  },
]

export const ORDER_STAGES = [
  { key: 'placed', label: 'Order placed' },
  { key: 'accepted', label: 'Restaurant accepted' },
  { key: 'preparing', label: 'Food preparing' },
  { key: 'pickup', label: 'Picked up' },
  { key: 'out_for_delivery', label: 'Out for delivery' },
  { key: 'delivered', label: 'Delivered' },
]
