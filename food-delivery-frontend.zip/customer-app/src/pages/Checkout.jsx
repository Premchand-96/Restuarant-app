import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/PageHeader'
import styles from './Checkout.module.css'

const PAYMENT_OPTIONS = [
  { key: 'upi', label: 'UPI', hint: 'Pay via any UPI app' },
  { key: 'card', label: 'Card', hint: 'Credit or debit card' },
  { key: 'netbanking', label: 'Net Banking', hint: 'All major banks' },
  { key: 'wallet', label: 'Wallet', hint: 'Paytm, PhonePe & more' },
  { key: 'cod', label: 'Cash on Delivery', hint: 'Pay when it arrives' },
]

export default function Checkout() {
  const { user, cart, cartTotals, selectedAddressId, setSelectedAddressId, placeOrder } = useApp()
  const navigate = useNavigate()
  const [payment, setPayment] = useState('upi')
  const [instructions, setInstructions] = useState('')
  const [placing, setPlacing] = useState(false)

  if (cart.items.length === 0) {
    navigate('/cart')
    return null
  }

  const handlePlaceOrder = () => {
    setPlacing(true)
    setTimeout(() => {
      const order = placeOrder(payment)
      navigate(`/order/${order.id}/track`)
    }, 700)
  }

  return (
    <div className="page">
      <PageHeader title="Checkout" />
      <div className="container">
        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Delivery address</h2>
          <div className={styles.addressList}>
            {user.addresses.map((addr) => (
              <label key={addr.id} className={`${styles.addressCard} ${selectedAddressId === addr.id ? styles.addressCardActive : ''}`}>
                <input
                  type="radio"
                  name="address"
                  checked={selectedAddressId === addr.id}
                  onChange={() => setSelectedAddressId(addr.id)}
                />
                <div>
                  <p className={styles.addrLabel}>{addr.label}</p>
                  <p className={styles.addrLine}>{addr.line}</p>
                </div>
              </label>
            ))}
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Delivery instructions</h2>
          <textarea
            className={styles.textarea}
            placeholder="E.g. Leave at the door, call on arrival..."
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            rows={3}
          />
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Payment method</h2>
          <div className={styles.paymentList}>
            {PAYMENT_OPTIONS.map((opt) => (
              <label key={opt.key} className={`${styles.paymentCard} ${payment === opt.key ? styles.paymentCardActive : ''}`}>
                <input
                  type="radio"
                  name="payment"
                  checked={payment === opt.key}
                  onChange={() => setPayment(opt.key)}
                />
                <div>
                  <p className={styles.payLabel}>{opt.label}</p>
                  <p className={styles.payHint}>{opt.hint}</p>
                </div>
              </label>
            ))}
          </div>
        </section>

        <section className={styles.section}>
          <div className={styles.billRow}><span>Item total</span><span>₹{cartTotals.subtotal}</span></div>
          <div className={styles.billRow}><span>Delivery fee</span><span>{cartTotals.deliveryFee === 0 ? 'FREE' : `₹${cartTotals.deliveryFee}`}</span></div>
          <div className={styles.billRow}><span>Taxes and charges</span><span>₹{cartTotals.taxes}</span></div>
        </section>
      </div>

      <div className={styles.footerBar}>
        <div>
          <p className={styles.total}>₹{cartTotals.total}</p>
          <p className={styles.totalSub}>TOTAL</p>
        </div>
        <button className="btn-primary" onClick={handlePlaceOrder} disabled={placing}>
          {placing ? 'Placing order…' : 'Place Order'}
        </button>
      </div>
    </div>
  )
}
