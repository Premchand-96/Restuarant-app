import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/PageHeader'
import styles from './Profile.module.css'

export default function Profile() {
  const { user, setIsAuthed, selectedAddressId, setSelectedAddressId } = useApp()
  const navigate = useNavigate()

  return (
    <div className="page">
      <PageHeader title="Profile" onBack={null} />
      <div className="container">
        <div className={styles.userCard}>
          <div className={styles.avatarLarge}>{user.name.split(' ').map((w) => w[0]).join('')}</div>
          <div>
            <p className={styles.userName}>{user.name}</p>
            <p className={styles.userContact}>{user.phone}</p>
            <p className={styles.userContact}>{user.email}</p>
          </div>
        </div>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Saved addresses</h2>
          {user.addresses.map((addr) => (
            <label key={addr.id} className={`${styles.row} ${selectedAddressId === addr.id ? styles.rowActive : ''}`}>
              <input
                type="radio"
                checked={selectedAddressId === addr.id}
                onChange={() => setSelectedAddressId(addr.id)}
              />
              <div>
                <p className={styles.rowTitle}>{addr.label}</p>
                <p className={styles.rowSub}>{addr.line}</p>
              </div>
            </label>
          ))}
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Payment methods</h2>
          {user.paymentMethods.map((pm) => (
            <div key={pm.id} className={styles.row}>
              <div>
                <p className={styles.rowTitle}>{pm.type}</p>
                <p className={styles.rowSub}>{pm.label}</p>
              </div>
            </div>
          ))}
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Settings</h2>
          <div className={styles.simpleRow}>Notifications</div>
          <div className={styles.simpleRow}>Favorites</div>
          <div className={styles.simpleRow}>Help & support</div>
        </section>

        <button
          className={styles.logoutBtn}
          onClick={() => {
            setIsAuthed(false)
            navigate('/login')
          }}
        >
          Log out
        </button>
      </div>
    </div>
  )
}
