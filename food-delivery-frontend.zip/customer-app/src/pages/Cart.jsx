import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import PageHeader from '../components/PageHeader'
import styles from './Cart.module.css'

export default function Cart() {
  const { cart, updateQty, cartTotals } = useApp()
  const navigate = useNavigate()

  if (cart.items.length === 0) {
    return (
      <div className="page">
        <PageHeader title="Cart" />
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>🛒</div>
          <h2>Your cart is empty</h2>
          <p>Add dishes from a restaurant to get started.</p>
          <Link to="/" className="btn-primary" style={{ display: 'inline-block', marginTop: 16 }}>
            Browse restaurants
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="page">
      <PageHeader title="Your Cart" subtitle={cart.restaurantName} />
      <div className="container">
        <div className={styles.itemList}>
          {cart.items.map((li) => (
            <div key={li.cartLineId} className={styles.item}>
              <div>
                <div className={styles.itemNameRow}>
                  <span className={li.veg ? 'veg-dot' : 'nonveg-dot'} />
                  <span className={styles.itemName}>{li.name}</span>
                </div>
                {li.chosenAddons?.length > 0 && (
                  <p className={styles.addonList}>+ {li.chosenAddons.map((a) => a.name).join(', ')}</p>
                )}
                <p className={styles.itemPrice}>₹{li.price + (li.chosenAddons || []).reduce((s, a) => s + a.price, 0)}</p>
              </div>
              <div className={styles.qtyStepper}>
                <button onClick={() => updateQty(li.cartLineId, -1)} aria-label="Decrease quantity">−</button>
                <span>{li.qty}</span>
                <button onClick={() => updateQty(li.cartLineId, 1)} aria-label="Increase quantity">+</button>
              </div>
            </div>
          ))}
        </div>

        <Link to={`/restaurant/${cart.restaurantId}`} className={styles.addMore}>
          + Add more items
        </Link>

        <hr className="rule" style={{ margin: '20px 0' }} />

        <div className={styles.billSection}>
          <h3 className={styles.billTitle}>Bill details</h3>
          <div className={styles.billRow}>
            <span>Item total</span>
            <span>₹{cartTotals.subtotal}</span>
          </div>
          <div className={styles.billRow}>
            <span>Delivery fee</span>
            <span>{cartTotals.deliveryFee === 0 ? 'FREE' : `₹${cartTotals.deliveryFee}`}</span>
          </div>
          <div className={styles.billRow}>
            <span>Taxes and charges</span>
            <span>₹{cartTotals.taxes}</span>
          </div>
          <hr className="rule" style={{ margin: '10px 0' }} />
          <div className={styles.billRowTotal}>
            <span>To pay</span>
            <span>₹{cartTotals.total}</span>
          </div>
        </div>
      </div>

      <div className={styles.checkoutBar}>
        <div>
          <p className={styles.checkoutTotal}>₹{cartTotals.total}</p>
          <p className={styles.checkoutSub}>TOTAL</p>
        </div>
        <button className="btn-primary" onClick={() => navigate('/checkout')}>
          Proceed to Checkout
        </button>
      </div>
    </div>
  )
}
