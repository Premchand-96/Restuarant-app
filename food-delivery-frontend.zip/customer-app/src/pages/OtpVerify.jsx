import { useState, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import styles from './Auth.module.css'

export default function OtpVerify() {
  const [digits, setDigits] = useState(['', '', '', ''])
  const inputs = useRef([])
  const navigate = useNavigate()
  const location = useLocation()
  const { setIsAuthed } = useApp()
  const phone = location.state?.phone || '98765 43210'

  const handleChange = (idx, value) => {
    if (!/^\d?$/.test(value)) return
    const next = [...digits]
    next[idx] = value
    setDigits(next)
    if (value && idx < 3) inputs.current[idx + 1]?.focus()
  }

  const handleKeyDown = (idx, e) => {
    if (e.key === 'Backspace' && !digits[idx] && idx > 0) inputs.current[idx - 1]?.focus()
  }

  const complete = digits.every((d) => d !== '')

  const handleVerify = () => {
    setIsAuthed(true)
    navigate('/')
  }

  return (
    <div className={styles.page}>
      <div className={styles.brand} style={{ marginTop: 40 }}>
        <div className={styles.logoMark}>🔐</div>
        <h1 className={styles.brandName}>Verify your number</h1>
        <p className={styles.tagline}>Enter the 4-digit code sent to +91 {phone}</p>
      </div>

      <div className={styles.card}>
        <div className={styles.otpRow}>
          {digits.map((d, idx) => (
            <input
              key={idx}
              ref={(el) => (inputs.current[idx] = el)}
              className={styles.otpBox}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={d}
              onChange={(e) => handleChange(idx, e.target.value)}
              onKeyDown={(e) => handleKeyDown(idx, e)}
              autoFocus={idx === 0}
            />
          ))}
        </div>
        <button className="btn-primary" style={{ width: '100%', marginTop: 22 }} disabled={!complete} onClick={handleVerify}>
          Verify & Continue
        </button>
        <button type="button" className={styles.resendLink}>
          Didn't get a code? Resend
        </button>
      </div>
    </div>
  )
}
