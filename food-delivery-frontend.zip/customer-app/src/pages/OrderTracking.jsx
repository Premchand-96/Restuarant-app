import { useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { ORDER_STAGES } from '../data/mockData'
import PageHeader from '../components/PageHeader'
import styles from './OrderTracking.module.css'

export default function OrderTracking() {
  const { orderId } = useParams()
  const navigate = useNavigate()
  const { activeOrder, advanceActiveOrder, orders } = useApp()

  const order = activeOrder?.id === orderId ? activeOrder : orders.find((o) => o.id === orderId)
  const stageIndex = order?.stageIndex ?? ORDER_STAGES.findIndex((s) => s.key === order?.status)

  // Auto-advance the order through stages so the flow feels alive without user action.
  useEffect(() => {
    if (!order || order.status === 'delivered' || order.status === 'cancelled') return
    if (activeOrder?.id !== orderId) return
    const timer = setTimeout(() => advanceActiveOrder(), 3200)
    return () => clearTimeout(timer)
  }, [order, activeOrder, orderId, advanceActiveOrder])

  if (!order) {
    return (
      <div className="page container">
        <p>Order not found.</p>
        <Link to="/orders" className="btn-primary" style={{ display: 'inline-block', marginTop: 12 }}>View orders</Link>
      </div>
    )
  }

  return (
    <div className="page">
      <PageHeader title="Track order" subtitle={order.id} onBack={() => navigate('/orders')} />
      <div className="container">
        <div className={styles.summaryCard}>
          <p className={styles.restaurantName}>{order.restaurantName}</p>
          <p className={styles.items}>{order.items.map((i) => `${i.qty}× ${i.name}`).join(', ')}</p>
          <p className={styles.total}>₹{order.total}</p>
        </div>

        <div className={styles.stages}>
          {ORDER_STAGES.map((stage, idx) => {
            const done = idx <= stageIndex
            const isCurrent = idx === stageIndex
            return (
              <div key={stage.key} className={styles.stageRow}>
                <div className={styles.stageMarkerCol}>
                  <div className={`${styles.dot} ${done ? styles.dotDone : ''} ${isCurrent ? styles.dotCurrent : ''}`} />
                  {idx < ORDER_STAGES.length - 1 && <div className={`${styles.connector} ${idx < stageIndex ? styles.connectorDone : ''}`} />}
                </div>
                <div className={styles.stageText}>
                  <p className={done ? styles.stageLabelDone : styles.stageLabel}>{stage.label}</p>
                  {isCurrent && stage.key !== 'delivered' && <p className={styles.stageHint}>In progress…</p>}
                  {isCurrent && stage.key === 'delivered' && <p className={styles.stageHint}>Enjoy your meal!</p>}
                </div>
              </div>
            )
          })}
        </div>

        {order.status === 'delivered' && (
          <Link to="/orders" className="btn-primary" style={{ display: 'block', textAlign: 'center', marginTop: 24 }}>
            View all orders
          </Link>
        )}
      </div>
    </div>
  )
}
