import { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { restaurants, menus } from '../data/mockData'
import { useApp } from '../context/AppContext'
import FoodPhoto from '../components/FoodPhoto'
import PageHeader from '../components/PageHeader'
import DishModal from '../components/DishModal'
import styles from './RestaurantDetail.module.css'

export default function RestaurantDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { cart } = useApp()
  const [activeDish, setActiveDish] = useState(null)

  const restaurant = restaurants.find((r) => r.id === id)
  const sections = menus[id] || []

  if (!restaurant) {
    return (
      <div className="page container">
        <p>Restaurant not found.</p>
        <Link to="/" className="btn-primary" style={{ display: 'inline-block', marginTop: 12 }}>Back home</Link>
      </div>
    )
  }

  const cartCount = cart.restaurantId === restaurant.id ? cart.items.reduce((s, i) => s + i.qty, 0) : 0

  return (
    <div className="page">
      <div className={styles.hero}>
        <FoodPhoto photoKey={restaurant.photo} label={restaurant.name} height={200} radius={0} />
        <button className={styles.backBtn} onClick={() => navigate(-1)} aria-label="Go back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      <div className="container">
        <div className={styles.info}>
          <h1 className={styles.name}>{restaurant.name}</h1>
          <p className={styles.cuisines}>{restaurant.cuisines.join(', ')}</p>
          <div className={styles.metaRow}>
            <span className={styles.ratingBadge}>★ {restaurant.rating}</span>
            <span className={styles.metaText}>{restaurant.ratingCount} ratings</span>
            <span className={styles.dot}>·</span>
            <span className={styles.metaText}>{restaurant.deliveryTime} mins</span>
          </div>
          <p className={styles.address}>{restaurant.address}</p>
          {restaurant.offer && <div className={styles.offerBanner}>🏷️ {restaurant.offer}</div>}
        </div>

        <hr className="rule" />

        {sections.map((sec) => (
          <section key={sec.category} className={styles.menuSection}>
            <h2 className={styles.sectionTitle}>{sec.category}</h2>
            <div className={styles.itemList}>
              {sec.items.map((item) => (
                <div key={item.id} className={styles.item}>
                  <div className={styles.itemInfo}>
                    <span className={item.veg ? 'veg-dot' : 'nonveg-dot'} />
                    {item.bestseller && <span className={styles.bestsellerTag}>Bestseller</span>}
                    <h3 className={styles.itemName}>{item.name}</h3>
                    <p className={styles.itemPrice}>₹{item.price}</p>
                    <p className={styles.itemDesc}>{item.desc}</p>
                  </div>
                  <div className={styles.itemAction}>
                    <FoodPhoto photoKey={restaurant.photo} label={item.name} height={84} radius={10} />
                    <button className={styles.addBtn} onClick={() => setActiveDish(item)}>
                      Add
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>

      {cartCount > 0 && (
        <button className={styles.viewCartBar} onClick={() => navigate('/cart')}>
          <span>{cartCount} item{cartCount !== 1 ? 's' : ''} added</span>
          <span className={styles.viewCartCta}>
            View Cart
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M9 6l6 6-6 6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
        </button>
      )}

      {activeDish && (
        <DishModal restaurant={restaurant} item={activeDish} onClose={() => setActiveDish(null)} />
      )}
    </div>
  )
}
