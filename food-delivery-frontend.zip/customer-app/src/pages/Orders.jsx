import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { restaurants, menus } from '../data/mockData'
import PageHeader from '../components/PageHeader'
import RatingModal from '../components/RatingModal'
import styles from './Orders.module.css'

const ACTIVE_STATUSES = ['placed', 'accepted', 'preparing', 'pickup', 'out_for_delivery']

export default function Orders() {
  const { orders, cancelOrder, addToCart } = useApp()
  const navigate = useNavigate()
  const [ratingOrder, setRatingOrder] = useState(null)

  const active = orders.filter((o) => ACTIVE_STATUSES.includes(o.status))
  const past = orders.filter((o) => !ACTIVE_STATUSES.includes(o.status))

  const handleReorder = (order) => {
    const restaurant = restaurants.find((r) => r.id === order.restaurantId)
    if (!restaurant) return
    const sections = menus[order.restaurantId] || []
    const allItems = sections.flatMap((s) => s.items)
    order.items.forEach((oi) => {
      const menuItem = allItems.find((mi) => mi.name === oi.name)
      if (menuItem) addToCart(restaurant, menuItem, oi.qty, [])
    })
    navigate('/cart')
  }

  return (
    <div className="page">
      <PageHeader title="Your Orders" onBack={null} />
      <div className="container">
        {orders.length === 0 && (
          <div className={styles.empty}>
            <p>No orders yet.</p>
            <Link to="/" className="btn-primary" style={{ display: 'inline-block', marginTop: 12 }}>Order now</Link>
          </div>
        )}

        {active.length > 0 && (
          <section className={styles.section}>
            <h2 className={styles.sectionTitle}>Active</h2>
            {active.map((o) => (
              <Link key={o.id} to={`/order/${o.id}/track`} className={styles.orderCard}>
                <div className={styles.orderTop}>
                  <p className={styles.restaurantName}>{o.restaurantName}</p>
                  <span className={styles.statusPill}>{formatStatus(o.status)}</span>
                </div>
                <p className={styles.itemsText}>{o.items.map((i) => `${i.qty}× ${i.name}`).join(', ')}</p>
                <p className={styles.footerRow}>₹{o.total} · Track order →</p>
              </Link>
            ))}
          </section>
        )}

        {past.length > 0 && (
          <section className={styles.section}>
            <h2 className={styles.sectionTitle}>Past orders</h2>
            {past.map((o) => (
              <div key={o.id} className={styles.orderCard}>
                <div className={styles.orderTop}>
                  <p className={styles.restaurantName}>{o.restaurantName}</p>
                  <span className={`${styles.statusPill} ${o.status === 'cancelled' ? styles.statusCancelled : styles.statusDelivered}`}>
                    {formatStatus(o.status)}
                  </span>
                </div>
                <p className={styles.itemsText}>{o.items.map((i) => `${i.qty}× ${i.name}`).join(', ')}</p>
                <p className={styles.dateText}>{new Date(o.placedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} · ₹{o.total}</p>
                <div className={styles.actionsRow}>
                  <button className="btn-secondary" onClick={() => handleReorder(o)}>Reorder</button>
                  {o.status === 'delivered' && !o.rated && (
                    <button className="btn-secondary" onClick={() => setRatingOrder(o)}>Rate order</button>
                  )}
                  {o.status === 'delivered' && o.rated && (
                    <span className={styles.ratedText}>★ Rated</span>
                  )}
                  {ACTIVE_STATUSES.includes(o.status) === false && o.status !== 'cancelled' && o.status !== 'delivered' && (
                    <button className={styles.cancelLink} onClick={() => cancelOrder(o.id)}>Cancel</button>
                  )}
                </div>
              </div>
            ))}
          </section>
        )}
      </div>

      {ratingOrder && <RatingModal order={ratingOrder} onClose={() => setRatingOrder(null)} />}
    </div>
  )
}

function formatStatus(status) {
  const map = {
    placed: 'Order placed',
    accepted: 'Accepted',
    preparing: 'Preparing',
    pickup: 'Picked up',
    out_for_delivery: 'On the way',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
  }
  return map[status] || status
}
