import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { restaurants, menus } from '../data/mockData'
import PageHeader from '../components/PageHeader'
import RestaurantCard from '../components/RestaurantCard'
import styles from './Search.module.css'

const SORTS = [
  { key: 'relevance', label: 'Relevance' },
  { key: 'rating', label: 'Rating' },
  { key: 'delivery', label: 'Delivery time' },
  { key: 'cost', label: 'Cost: low to high' },
]

export default function Search() {
  const [params, setParams] = useSearchParams()
  const initialQuery = params.get('category') || ''
  const [query, setQuery] = useState(initialQuery)
  const [vegOnly, setVegOnly] = useState(false)
  const [minRating, setMinRating] = useState(0)
  const [sort, setSort] = useState('relevance')

  const dishMatches = useMemo(() => {
    if (!query.trim()) return new Set()
    const q = query.toLowerCase()
    const ids = new Set()
    Object.entries(menus).forEach(([restaurantId, sections]) => {
      sections.forEach((sec) => {
        sec.items.forEach((item) => {
          if (item.name.toLowerCase().includes(q)) ids.add(restaurantId)
        })
      })
    })
    return ids
  }, [query])

  const results = useMemo(() => {
    let list = restaurants
    if (query.trim()) {
      const q = query.toLowerCase()
      list = list.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.cuisines.some((c) => c.toLowerCase().includes(q)) ||
          dishMatches.has(r.id)
      )
    }
    if (vegOnly) list = list.filter((r) => r.veg)
    if (minRating > 0) list = list.filter((r) => r.rating >= minRating)

    const sorted = [...list]
    if (sort === 'rating') sorted.sort((a, b) => b.rating - a.rating)
    if (sort === 'delivery') sorted.sort((a, b) => a.deliveryTime - b.deliveryTime)
    if (sort === 'cost') sorted.sort((a, b) => a.priceForTwo - b.priceForTwo)
    return sorted
  }, [query, vegOnly, minRating, sort, dishMatches])

  return (
    <div className="page">
      <PageHeader title="Search" onBack={null} />
      <div className="container">
        <div className={styles.searchBox}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="6.5" stroke="#8C8577" strokeWidth="1.8" />
            <path d="M20 20l-4.5-4.5" stroke="#8C8577" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setParams({})
            }}
            placeholder="Search restaurants or dishes"
            autoFocus={!initialQuery}
          />
        </div>

        <div className={styles.filterRow}>
          <button
            className={`${styles.chip} ${vegOnly ? styles.chipActive : ''}`}
            onClick={() => setVegOnly((v) => !v)}
          >
            <span className="veg-dot" /> Veg only
          </button>
          {[4.0, 4.3, 4.5].map((r) => (
            <button
              key={r}
              className={`${styles.chip} ${minRating === r ? styles.chipActive : ''}`}
              onClick={() => setMinRating((cur) => (cur === r ? 0 : r))}
            >
              ★ {r}+
            </button>
          ))}
        </div>

        <div className={styles.sortRow}>
          {SORTS.map((s) => (
            <button
              key={s.key}
              className={`${styles.sortChip} ${sort === s.key ? styles.sortChipActive : ''}`}
              onClick={() => setSort(s.key)}
            >
              {s.label}
            </button>
          ))}
        </div>

        <p className={styles.resultCount}>{results.length} restaurant{results.length !== 1 ? 's' : ''} found</p>

        <div className={styles.cardList}>
          {results.map((r) => (
            <RestaurantCard key={r.id} restaurant={r} />
          ))}
          {results.length === 0 && (
            <div className={styles.empty}>
              <p>No restaurants match those filters.</p>
              <p className={styles.emptySub}>Try widening your search or clearing a filter.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
