import { Link } from 'react-router-dom'
import { categories, restaurants } from '../data/mockData'
import { useApp } from '../context/AppContext'
import RestaurantCard from '../components/RestaurantCard'
import styles from './Home.module.css'

export default function Home() {
  const { user, selectedAddressId } = useApp()
  const address = user.addresses.find((a) => a.id === selectedAddressId)
  const topRated = [...restaurants].sort((a, b) => b.rating - a.rating).slice(0, 3)

  return (
    <div className="page">
      <div className={styles.topBar}>
        <Link to="/profile" className={styles.locationBtn}>
          <span className={styles.locationLabel}>Deliver to</span>
          <span className={styles.locationValue}>
            {address?.label} · {address?.line.split(',')[0]}
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ marginLeft: 4 }}>
              <path d="M6 9l6 6 6-6" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
        </Link>
        <Link to="/profile" className={styles.avatar} aria-label="Profile">
          {user.name.split(' ').map((w) => w[0]).join('')}
        </Link>
      </div>

      <div className="container">
        <Link to="/search" className={styles.searchBar}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="6.5" stroke="#8C8577" strokeWidth="1.8" />
            <path d="M20 20l-4.5-4.5" stroke="#8C8577" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <span>Search restaurants or dishes</span>
        </Link>
      </div>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>What are you craving?</h2>
        <div className={styles.categoryRow}>
          {categories.map((c) => (
            <Link key={c.id} to={`/search?category=${encodeURIComponent(c.name)}`} className={styles.categoryChip}>
              <span className={styles.categoryEmoji}>{c.emoji}</span>
              <span>{c.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>Top rated near you</h2>
        <div className={styles.cardList}>
          {topRated.map((r) => (
            <RestaurantCard key={r.id} restaurant={r} />
          ))}
        </div>
      </section>

      <section className={styles.section}>
        <h2 className={styles.sectionTitle}>All restaurants</h2>
        <div className={styles.cardList}>
          {restaurants.map((r) => (
            <RestaurantCard key={r.id} restaurant={r} />
          ))}
        </div>
      </section>
    </div>
  )
}
