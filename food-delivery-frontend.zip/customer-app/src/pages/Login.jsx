import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import styles from './Auth.module.css'

export default function Login() {
  const [phone, setPhone] = useState('')
  const navigate = useNavigate()

  const handleContinue = (e) => {
    e.preventDefault()
    if (phone.trim().length < 10) return
    navigate('/otp', { state: { phone } })
  }

  return (
    <div className={styles.page}>
      <div className={styles.brand}>
        <div className={styles.logoMark}>🍽</div>
        <h1 className={styles.brandName}>Tirumala Eats</h1>
        <p className={styles.tagline}>Order food from your favorite local restaurants</p>
      </div>

      <form className={styles.card} onSubmit={handleContinue}>
        <h2 className={styles.formTitle}>Log in or sign up</h2>
        <label className={styles.label}>Mobile number</label>
        <div className={styles.phoneRow}>
          <span className={styles.prefix}>+91</span>
          <input
            className={styles.input}
            type="tel"
            inputMode="numeric"
            maxLength={10}
            placeholder="98765 43210"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
          />
        </div>
        <button className="btn-primary" style={{ width: '100%', marginTop: 18 }} disabled={phone.length < 10}>
          Continue
        </button>

        <div className={styles.divider}><span>or</span></div>

        <button type="button" className="btn-secondary" style={{ width: '100%' }}>
          Continue with Google
        </button>
      </form>

      <p className={styles.footerText}>
        By continuing, you agree to our Terms of Service and Privacy Policy.
      </p>
    </div>
  )
}
