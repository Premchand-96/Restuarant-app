import { Link } from 'react-router-dom'
import FoodPhoto from './FoodPhoto'
import styles from './RestaurantCard.module.css'

export default function RestaurantCard({ restaurant }) {
  return (
    <Link to={`/restaurant/${restaurant.id}`} className={styles.card}>
      <FoodPhoto photoKey={restaurant.photo} label={restaurant.name} height={128} />
      <div className={styles.body}>
        <div className={styles.topRow}>
          <h3 className={styles.name}>{restaurant.name}</h3>
          <span className={styles.rating}>★ {restaurant.rating}</span>
        </div>
        <p className={styles.cuisines}>{restaurant.cuisines.join(', ')}</p>
        <p className={styles.meta}>
          {restaurant.deliveryTime} mins · ₹{restaurant.priceForTwo} for two · {restaurant.distanceKm} km
        </p>
        {restaurant.offer && <p className={styles.offer}>{restaurant.offer}</p>}
      </div>
    </Link>
  )
}
