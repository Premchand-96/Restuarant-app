import { useNavigate } from 'react-router-dom'
import styles from './PageHeader.module.css'

export default function PageHeader({ title, subtitle, onBack, right }) {
  const navigate = useNavigate()
  return (
    <header className={styles.header}>
      <div className={styles.left}>
        {onBack !== null && (
          <button className={styles.backBtn} onClick={onBack || (() => navigate(-1))} aria-label="Go back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M15 18l-6-6 6-6" stroke="#1A1A1A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        )}
        <div>
          <h1 className={styles.title}>{title}</h1>
          {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
        </div>
      </div>
      {right && <div className={styles.right}>{right}</div>}
    </header>
  )
}
