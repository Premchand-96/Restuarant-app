import { NavLink } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import styles from './BottomNav.module.css'

const ICONS = {
  home: (active) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M4 11.5L12 4l8 7.5" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M6 10v9a1 1 0 001 1h10a1 1 0 001-1v-9" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  search: (active) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="11" r="6.5" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" />
      <path d="M20 20l-4.5-4.5" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  ),
  orders: (active) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="5" y="4" width="14" height="17" rx="2" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" />
      <path d="M8.5 9h7M8.5 13h7M8.5 17h4" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  ),
  profile: (active) => (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="8" r="3.5" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" />
      <path d="M4.5 20c1.5-4 4.5-6 7.5-6s6 2 7.5 6" stroke={active ? '#E8552C' : '#8C8577'} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  ),
}

const TABS = [
  { to: '/', key: 'home', label: 'Home' },
  { to: '/search', key: 'search', label: 'Search' },
  { to: '/orders', key: 'orders', label: 'Orders' },
  { to: '/profile', key: 'profile', label: 'Profile' },
]

export default function BottomNav() {
  const { cart } = useApp()
  const cartCount = cart.items.reduce((s, i) => s + i.qty, 0)

  return (
    <nav className={styles.nav} aria-label="Primary">
      {TABS.map((tab) => (
        <NavLink
          key={tab.key}
          to={tab.to}
          end={tab.to === '/'}
          className={({ isActive }) => `${styles.tab} ${isActive ? styles.active : ''}`}
        >
          {({ isActive }) => (
            <>
              <span className={styles.iconWrap}>
                {ICONS[tab.key](isActive)}
                {tab.key === 'orders' && cartCount > 0 && cart.restaurantId && (
                  <span className={styles.badge}>{cartCount}</span>
                )}
              </span>
              <span className={isActive ? styles.labelActive : styles.label}>{tab.label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  )
}
