import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { addons as addonsData } from '../data/mockData'
import { useApp } from '../context/AppContext'
import styles from './DishModal.module.css'

export default function DishModal({ restaurant, item, onClose }) {
  const { addToCart, cart } = useApp()
  const navigate = useNavigate()
  const [qty, setQty] = useState(1)
  const [selectedAddons, setSelectedAddons] = useState([])
  const [switchWarning, setSwitchWarning] = useState(false)

  const availableAddons = addonsData[item.id] || []

  const toggleAddon = (addon) => {
    setSelectedAddons((prev) =>
      prev.find((a) => a.id === addon.id) ? prev.filter((a) => a.id !== addon.id) : [...prev, addon]
    )
  }

  const addonTotal = selectedAddons.reduce((s, a) => s + a.price, 0)
  const lineTotal = (item.price + addonTotal) * qty

  const handleAdd = () => {
    if (cart.restaurantId && cart.restaurantId !== restaurant.id && cart.items.length > 0 && !switchWarning) {
      setSwitchWarning(true)
      return
    }
    addToCart(restaurant, item, qty, selectedAddons)
    onClose()
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.sheet} onClick={(e) => e.stopPropagation()}>
        <div className={styles.handle} />
        <div className={styles.headerRow}>
          <span className={item.veg ? 'veg-dot' : 'nonveg-dot'} />
          <h2 className={styles.title}>{item.name}</h2>
        </div>
        <p className={styles.desc}>{item.desc}</p>
        <p className={styles.basePrice}>₹{item.price}</p>

        {switchWarning && (
          <div className={styles.warning}>
            <p>Your cart has items from <strong>{cart.restaurantName}</strong>. Adding this will start a new cart for <strong>{restaurant.name}</strong>.</p>
            <div className={styles.warningActions}>
              <button className="btn-secondary" onClick={onClose}>Cancel</button>
              <button className="btn-primary" onClick={handleAdd}>Start new cart</button>
            </div>
          </div>
        )}

        {!switchWarning && (
          <>
            {availableAddons.length > 0 && (
              <div className={styles.addonSection}>
                <h3 className={styles.addonTitle}>Add-ons</h3>
                {availableAddons.map((addon) => (
                  <label key={addon.id} className={styles.addonRow}>
                    <span className={styles.addonLeft}>
                      <input
                        type="checkbox"
                        checked={!!selectedAddons.find((a) => a.id === addon.id)}
                        onChange={() => toggleAddon(addon)}
                      />
                      {addon.name}
                    </span>
                    <span>₹{addon.price}</span>
                  </label>
                ))}
              </div>
            )}

            <div className={styles.footer}>
              <div className={styles.qtyStepper}>
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="Decrease quantity">−</button>
                <span>{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} aria-label="Increase quantity">+</button>
              </div>
              <button className="btn-primary" onClick={handleAdd} style={{ flex: 1 }}>
                Add item · ₹{lineTotal}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
