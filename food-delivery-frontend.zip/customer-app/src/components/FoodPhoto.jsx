// Stand-in for real restaurant/dish photography. Deterministic gradient
// per "photo" key so the same restaurant always looks the same.
const PALETTES = {
  'biryani-restaurant': ['#D97B3E', '#8C3E1E'],
  'south-indian': ['#4E8B5C', '#2B5738'],
  'pizza': ['#D9432E', '#8C2318'],
  'chinese': ['#C4472B', '#7A2314'],
  'desserts': ['#D98E3E', '#B85E1E'],
  'burgers': ['#8C5A2B', '#5C3A1A'],
  default: ['#C97A4A', '#8C4E2B'],
}

export default function FoodPhoto({ photoKey, label, height = 140, radius = 12 }) {
  const [c1, c2] = PALETTES[photoKey] || PALETTES.default
  const initials = (label || '').split(' ').slice(0, 2).map((w) => w[0]).join('').toUpperCase()
  return (
    <div
      style={{
        height,
        borderRadius: radius,
        background: `linear-gradient(135deg, ${c1}, ${c2})`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'rgba(255,255,255,0.85)',
        fontFamily: 'var(--font-display)',
        fontSize: height / 3.4,
        fontWeight: 600,
        letterSpacing: '0.02em',
        flexShrink: 0,
      }}
      aria-hidden="true"
    >
      {initials}
    </div>
  )
}
