import { useState } from 'react'
import { useApp } from '../context/AppContext'
import styles from './DishModal.module.css'

export default function RatingModal({ order, onClose }) {
  const { rateOrder } = useApp()
  const [restaurantRating, setRestaurantRating] = useState(0)
  const [foodRating, setFoodRating] = useState(0)
  const [deliveryRating, setDeliveryRating] = useState(0)

  const handleSubmit = () => {
    rateOrder(order.id)
    onClose()
  }

  const Stars = ({ value, onChange }) => (
    <div style={{ display: 'flex', gap: 6 }}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          onClick={() => onChange(n)}
          style={{ background: 'none', border: 'none', fontSize: 26, color: n <= value ? '#E8552C' : '#E4D9C8', padding: 0 }}
          aria-label={`${n} star`}
        >
          ★
        </button>
      ))}
    </div>
  )

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.sheet} onClick={(e) => e.stopPropagation()}>
        <div className={styles.handle} />
        <h2 className={styles.title}>Rate your order</h2>
        <p className={styles.desc}>{order.restaurantName}</p>

        <div style={{ marginTop: 20 }}>
          <p style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Restaurant</p>
          <Stars value={restaurantRating} onChange={setRestaurantRating} />
        </div>
        <div style={{ marginTop: 18 }}>
          <p style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Food</p>
          <Stars value={foodRating} onChange={setFoodRating} />
        </div>
        <div style={{ marginTop: 18 }}>
          <p style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Delivery</p>
          <Stars value={deliveryRating} onChange={setDeliveryRating} />
        </div>

        <button
          className="btn-primary"
          style={{ width: '100%', marginTop: 24 }}
          disabled={!restaurantRating || !foodRating || !deliveryRating}
          onClick={handleSubmit}
        >
          Submit rating
        </button>
      </div>
    </div>
  )
}
