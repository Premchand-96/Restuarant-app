import { createContext, useContext, useState, useMemo, useCallback } from 'react'
import { mockUser, initialOrders, ORDER_STAGES } from '../data/mockData'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [isAuthed, setIsAuthed] = useState(true) // start signed-in so reviewers see the full flow
  const [user] = useState(mockUser)
  const [cart, setCart] = useState({ restaurantId: null, restaurantName: null, items: [] })
  const [orders, setOrders] = useState(initialOrders)
  const [activeOrder, setActiveOrder] = useState(null)
  const [selectedAddressId, setSelectedAddressId] = useState(mockUser.addresses[0].id)

  const addToCart = useCallback((restaurant, item, qty, chosenAddons = []) => {
    setCart((prev) => {
      // Switching restaurants clears the cart, like every real food app does.
      if (prev.restaurantId && prev.restaurantId !== restaurant.id) {
        return {
          restaurantId: restaurant.id,
          restaurantName: restaurant.name,
          items: [{ ...item, qty, chosenAddons, cartLineId: `${item.id}-${Date.now()}` }],
        }
      }
      const existing = prev.items.find((li) => li.id === item.id && JSON.stringify(li.chosenAddons) === JSON.stringify(chosenAddons))
      if (existing) {
        return {
          ...prev,
          restaurantId: restaurant.id,
          restaurantName: restaurant.name,
          items: prev.items.map((li) => (li.cartLineId === existing.cartLineId ? { ...li, qty: li.qty + qty } : li)),
        }
      }
      return {
        restaurantId: restaurant.id,
        restaurantName: restaurant.name,
        items: [...prev.items, { ...item, qty, chosenAddons, cartLineId: `${item.id}-${Date.now()}` }],
      }
    })
  }, [])

  const updateQty = useCallback((cartLineId, delta) => {
    setCart((prev) => {
      const items = prev.items
        .map((li) => (li.cartLineId === cartLineId ? { ...li, qty: li.qty + delta } : li))
        .filter((li) => li.qty > 0)
      return { ...prev, items, restaurantId: items.length ? prev.restaurantId : null, restaurantName: items.length ? prev.restaurantName : null }
    })
  }, [])

  const clearCart = useCallback(() => setCart({ restaurantId: null, restaurantName: null, items: [] }), [])

  const cartTotals = useMemo(() => {
    const subtotal = cart.items.reduce((sum, li) => {
      const addonTotal = (li.chosenAddons || []).reduce((s, a) => s + a.price, 0)
      return sum + (li.price + addonTotal) * li.qty
    }, 0)
    const deliveryFee = subtotal > 0 ? (subtotal > 400 ? 0 : 35) : 0
    const taxes = Math.round(subtotal * 0.05)
    const total = subtotal + deliveryFee + taxes
    return { subtotal, deliveryFee, taxes, total }
  }, [cart.items])

  const placeOrder = useCallback((paymentMethod) => {
    const newOrder = {
      id: `ORD${1000 + orders.length + 3}`,
      restaurantId: cart.restaurantId,
      restaurantName: cart.restaurantName,
      items: cart.items.map((li) => ({ name: li.name, qty: li.qty, price: li.price })),
      total: cartTotals.total,
      status: 'placed',
      placedAt: new Date().toISOString(),
      rated: false,
      paymentMethod,
      stageIndex: 0,
    }
    setOrders((prev) => [newOrder, ...prev])
    setActiveOrder(newOrder)
    clearCart()
    return newOrder
  }, [cart, cartTotals, orders.length, clearCart])

  const advanceActiveOrder = useCallback(() => {
    setActiveOrder((prev) => {
      if (!prev) return prev
      const nextIndex = Math.min((prev.stageIndex ?? 0) + 1, ORDER_STAGES.length - 1)
      const nextStatus = ORDER_STAGES[nextIndex].key
      setOrders((os) => os.map((o) => (o.id === prev.id ? { ...o, status: nextStatus, stageIndex: nextIndex } : o)))
      return { ...prev, stageIndex: nextIndex, status: nextStatus }
    })
  }, [])

  const rateOrder = useCallback((orderId) => {
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, rated: true } : o)))
  }, [])

  const cancelOrder = useCallback((orderId) => {
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status: 'cancelled' } : o)))
  }, [])

  const value = {
    isAuthed, setIsAuthed,
    user,
    cart, addToCart, updateQty, clearCart, cartTotals,
    orders, placeOrder, activeOrder, advanceActiveOrder, rateOrder, cancelOrder,
    selectedAddressId, setSelectedAddressId,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
